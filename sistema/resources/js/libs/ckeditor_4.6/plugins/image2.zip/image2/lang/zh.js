/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'zh', {
	alt: '替代文字',
	btnUpload: '傳送至伺服器',
	captioned: '已加標題之圖片',
	captionPlaceholder: '標題',
	infoTab: '影像資訊',
	lockRatio: '固定比例',
	menu: '影像屬性',
	pathName: '圖片',
	pathNameCaption: '標題',
	resetSize: '重設大小',
	resizer: '拖曳以改變大小',
	title: '影像屬性',
	uploadTab: '上傳',
	urlMissing: '遺失圖片來源之 URL ',
	altMissing: '替代文字遺失。'
} );
